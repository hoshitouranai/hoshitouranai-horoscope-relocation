import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import vm from 'node:vm';
import {SampledEphemeris,BODY_NAMES,jstSampleStep,jstToUtcMs,utcMsToJst,placidusHouses,shortestSeparation} from '../src/index.mjs';
const relative=(p)=>readFileSync(fileURLToPath(new URL(p,import.meta.url)));
const p=relative('../data/ephemeris_2000_2050_3h.bin');
const e=relative('../data/earth_orientation_2000_2050_3h.bin');
const stations=JSON.parse(relative('../data/stations.json'));
const engine=new SampledEphemeris(p,e,stations);
const wrap=angle=>((angle%360)+360)%360;
const context={samples:new DataView(p.buffer,p.byteOffset,p.byteLength),earthSamples:new DataView(e.buffer,e.byteOffset,e.byteLength),stations,names:BODY_NAMES,scale:10000000,wrap,rad:Math.PI/180,Math,Array,Boolean};
vm.createContext(context);
for(const name of ['position','earthOrientation','houses']){
 const filename=name==='houses'?'original_houses_reference.js':`original_${name}_reference.js`;
 vm.runInContext(relative(`../research/${filename}`).toString(),context);
}
const original=(name,...args)=>vm.runInContext(`${name}(${args.map(x=>JSON.stringify(x)).join(',')})`,context);
test('original three house algorithms byte-identical',()=>{
 const records=JSON.parse(relative('../research/original_sources.json'));
 assert.equal(new Set(records.map(x=>x.houses_function_sha256)).size,1);
});
test('JST input conversion, leap day, month-end and invalid dates',()=>{
 assert.equal(new Date(jstToUtcMs('2026-11-13','19:11')).toISOString(),'2026-11-13T10:11:00.000Z');
 assert.deepEqual(utcMsToJst(Date.parse('2026-11-13T10:11:00Z')),{date:'2026-11-13',time:'19:11'});
 assert.deepEqual(utcMsToJst(jstToUtcMs('2024-02-29','00:00')),{date:'2024-02-29',time:'00:00'});
 assert.throws(()=>jstSampleStep('2025-02-29','12:00'),RangeError);
 assert.throws(()=>jstSampleStep('2026-11-13','24:00'),RangeError);
 assert.equal(jstSampleStep('2000-01-01','00:00'),0);
 assert.equal(jstSampleStep('2000-01-01','03:00'),1);
});
test('position and retrograde exactly reproduce source interpolation',()=>{
 for(let i=0;i<BODY_NAMES.length;i++){
  for(const step of [0,0.01,1,8,101.17,2532.5,18432,45000.337,72000.75,118000.1,149022.999]){
   const got=engine.position(i,step),ref=original('position',i,step);
   assert.ok(Math.abs(got.longitude-ref.longitude)<1e-11, `${i},${step}`);
   assert.equal(got.retrograde,ref.retrograde);
  }
 }
 assert.throws(()=>engine.position(0,-1),RangeError);
 assert.throws(()=>engine.position(0,engine.count),RangeError);
});
test('orientation exactly reproduces source',()=>{
 for(const step of [0,.5,1,77.125,1000,60000.3456,100000.75,149023.9]){
  const x=engine.orientation(step),ref=original('earthOrientation',step);
  assert.ok(Math.abs(x.theta-ref[0])<1e-11);
  assert.ok(Math.abs(x.obliquity-ref[1])<1e-11);
 }
});
test('Placidus legacy outputs exactly match source across locations',()=>{
 for(const step of [0,151.25,6000,57000.2,105000.88,149022.2]){
  const {theta,obliquity}=engine.orientation(step);
  for(const [lat,lon] of [[35.676,139.745],[43.06401,141.34693],[-33.86,151.2],[0,0],[67.1,15.4],[80,10]]){
   const x=placidusHouses(theta,obliquity,lat,lon),ref=original('houses',theta,obliquity,lat,lon);
   assert.equal(x.house,ref.house);
   assert.equal(x.cusps.length,12);
   for(let k=0;k<12;k++)assert.ok(Math.abs(x.cusps[k]-ref.cusps[k])<1e-10,`${step},${lat},${k}`);
  }
 }
});
test('chart API seven classical planets and angular separation',()=>{
 const chart=engine.chart('2026-11-13','19:11',[0,1,2,3,4,5,6]);
 assert.equal(chart.bodies.length,7);
 assert.equal(chart.timeZone,'Asia/Tokyo');
 assert.ok(chart.bodies.every(x=>x.longitude>=0&&x.longitude<360));
 assert.equal(shortestSeparation(350,10),20);
});
