import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {solarGeometricAltitude,chartSect,SampledEphemeris} from '../src/index.mjs';
const parts=(p)=>readFileSync(fileURLToPath(new URL(p,import.meta.url)));
const engine=new SampledEphemeris(parts('../data/ephemeris_2000_2050_3h.bin'),parts('../data/earth_orientation_2000_2050_3h.bin'),JSON.parse(parts('../data/stations.json')));
test('equinox equatorial geometry day/night and horizon',()=>{
 assert.ok(solarGeometricAltitude(0,0,23.44,0,0)>89.99);
 assert.ok(solarGeometricAltitude(0,180,23.44,0,0)<-89.99);
 assert.ok(Math.abs(solarGeometricAltitude(0,90,23.44,0,0))<1e-8);
});
test('sect from real chart reverses with anti-meridian location',()=>{
 const chart=engine.chart('2026-11-13','12:00',[0,1,2,3,4,5,6]);
 const japan=chartSect(chart,36,140);
 const opposite=chartSect(chart,-36,-40);
 assert.notEqual(japan.sect,opposite.sect);
});
test('near-horizon is explicitly undecided rather than silently classified',()=>{
 const c={bodies:[{name:'太陽',longitude:0}],orientation:{theta:90,obliquity:23.44}};
 assert.equal(chartSect(c,0,0).sect,null);
 assert.equal(chartSect(c,0,0).uncertain,true);
 assert.ok(['day','night'].includes(chartSect(c,0,0,{horizonToleranceDeg:0}).sect));
});
