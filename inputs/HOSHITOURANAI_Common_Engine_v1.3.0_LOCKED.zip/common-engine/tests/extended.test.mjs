import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {aspectsAt, BODY_NAMES, civilTimeToUtc, jstSampleStep, loadEphemerisSegment,
  loadHistoricalTimezones, loadSampledEphemeris, shortestSeparation} from '../src/index.mjs';

const engine = await loadSampledEphemeris();
test('all twelve bodies and angles at both endpoints, leap day and seams', () => {
  for (const [date,time] of [['1900-01-01','00:00'], ['1904-02-29','14:05'],
    ['1999-12-31','23:59'], ['2000-01-01','00:00'], ['2050-12-31','23:59'],
    ['2051-01-01','00:00'], ['2100-12-31','23:59']]) {
    const chart = engine.chart(date,time);
    assert.equal(chart.bodies.length,BODY_NAMES.length);
    assert.ok(chart.bodies.every(({longitude}) => longitude >= 0 && longitude < 360));
    assert.ok(chart.orientation.theta >= 0 && chart.orientation.theta < 360);
    assert.ok(Math.abs(chart.orientation.obliquity - 23.4) < 0.1);
    assert.deepEqual(engine.position(1,jstSampleStep(date,time)), chart.bodies[1]);
  }
  for (const date of ['1899-12-31','2101-01-01','2100-02-29']) {
    assert.throws(() => engine.chart(date,'00:00'), RangeError);
  }
});
test('the legacy period still produces identical results via both loaders', async () => {
  const segment = await loadEphemerisSegment('2000-01-01');
  for (const [day,time] of [['2000-01-01','00:00'],['2026-11-14','12:34'],['2050-12-31','23:59']]) {
    assert.deepEqual(engine.chart(day,time),segment.chart(day,time));
  }
});
test('seam endpoints match the adjacent source to sampling tolerance', async () => {
  for (const [date,left,right] of [['2000-01-01','1900_1999','2000_2050'],['2051-01-01','2000_2050','2051_2100']]) {
    const a = await readFile(new URL(`../data/ephemeris_${left}_3h.bin`,import.meta.url));
    const b = await readFile(new URL(`../data/ephemeris_${right}_3h.bin`,import.meta.url));
    for (let i=0;i<12;i++) {
      const expected = a.readInt32LE(a.length-96+i*8)/1e7;
      assert.ok(shortestSeparation(expected,b.readInt32LE(i*8)/1e7) < 0.001,`${date}, body ${i}`);
    }
  }
});
test('minor aspect, grand sextile with all fifteen edges, and P12', () => {
  const chart = aspectsAt([0,60,120,180,240,300,30,45,155,259,1,2]);
  assert.ok(chart.pairs.some(({i,j,ang,kind}) => i===0 && j===6 && ang===30 && kind==='minor'));
  assert.ok(chart.patterns.some(({name,requiredEdgeIds}) => name==='グランドセクスタイル' && requiredEdgeIds.length===15));
  assert.ok(chart.concentrations.some(({ids}) => ids.join(',')==='0,10,11'));
  assert.ok(chart.overlaps.length>0);
  assert.throws(() => aspectsAt(Array(12)),TypeError);
});
test('projection through 2100 uses the bundled zone rules', async () => {
  const db = await loadHistoricalTimezones();
  assert.equal(civilTimeToUtc(db,{date:'2100-07-01',time:'12:00',timeZone:'America/New_York'}).offsetSeconds,-14400);
  assert.equal(civilTimeToUtc(db,{date:'2100-12-31',time:'23:59',timeZone:'Asia/Tokyo'}).utcIso,'2100-12-31T14:59:00.000Z');
});
