import test from 'node:test';
import assert from 'node:assert/strict';
import {longitudeMidpoints,renderWheelSvg,renderLayeredWheelSvg,wheelPoint} from '../src/index.mjs';

test('midpoints cross zodiac zero and are independent of input order',()=>{
 assert.deepEqual(longitudeMidpoints(355,5),{midpoint:0,opposite:180});
 assert.deepEqual(longitudeMidpoints(5,-5),longitudeMidpoints(355,5));
 assert.deepEqual(longitudeMidpoints(30,30),{midpoint:30,opposite:210});
 assert.deepEqual(longitudeMidpoints(180,0),{midpoint:null,opposite:null,candidates:[90,270]});
 assert.throws(()=>longitudeMidpoints(NaN,0),RangeError);
});

test('one layer matches existing SVG; two and three layers share inner ASC',()=>{
 const cusps=Array.from({length:12},(_,i)=>i*30);
 const inner={cusps,ascendant:90,planets:[{name:'太陽',longitude:90}]};
 const outer={cusps,ascendant:0,label:'<外円>',planets:[{name:'月',longitude:90}]};
 assert.equal(renderLayeredWheelSvg([inner]),renderWheelSvg(inner));
 assert.equal((renderLayeredWheelSvg([inner,outer]).match(/<g /g)||[]).length,2);
 const svg=renderLayeredWheelSvg([inner,outer,outer]);
 assert.equal((svg.match(/<g /g)||[]).length,3);
 assert.ok(svg.includes('&lt;外円&gt;'));
 for (const radius of [129,185,241]) {
  const [x,y]=wheelPoint(90,radius,90).map(n=>Number(n.toFixed(4)));
  assert.ok(svg.includes(`x="${x}" y="${y}"`));
 }
 assert.throws(()=>renderLayeredWheelSvg([]),RangeError);
});
