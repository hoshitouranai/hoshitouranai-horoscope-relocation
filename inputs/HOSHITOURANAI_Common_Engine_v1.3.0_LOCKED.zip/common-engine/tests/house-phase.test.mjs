import test from 'node:test';
import assert from 'node:assert/strict';
import {wholeSignHouses,naturalHouses,sunSignHouses,equalHouses,
  loadSampledEphemeris,loadEphemerisSegment,moonPhaseAt,findMoonPhases,jstToUtcMs} from '../src/index.mjs';

test('four house systems preserve their specified origins and wrap at 360',()=>{
  assert.deepEqual(wholeSignHouses(230,140).cusps.slice(0,6),[210,240,270,300,330,0]);
  assert.equal(wholeSignHouses(230,140).asc,230);
  assert.equal(wholeSignHouses(230,140).mc,140);
  assert.equal(naturalHouses().cusps[11],330);
  assert.equal(naturalHouses().asc,undefined);
  assert.deepEqual(sunSignHouses(337.85).cusps.slice(0,3),[330,0,30]);
  assert.deepEqual(equalHouses(230).cusps.slice(0,6),[230,260,290,320,350,20]);
  assert.throws(()=>equalHouses(Infinity),RangeError);
});

const engine=await loadSampledEphemeris();
test('eight lunar events in chronological order, consistent across segment loader',async()=>{
  const start=jstToUtcMs('2024-04-08','00:00'),end=jstToUtcMs('2024-05-08','00:00');
  const events=findMoonPhases(engine,start,end);
  assert.deepEqual(events.map(e=>e.angle),[0,45,90,135,180,225,270,315]);
  for (const event of events) {
    assert.equal(moonPhaseAt(engine,event.utcMs).index,event.index);
    assert.deepEqual(findMoonPhases(engine,event.utcMs,event.utcMs+1),[event]);
    assert.deepEqual(findMoonPhases(engine,event.utcMs-1,event.utcMs),[]);
  }
  const segment=await loadEphemerisSegment('1900-01-01');
  const left=jstToUtcMs('1900-01-01','00:00'),right=jstToUtcMs('1900-02-01','00:00');
  assert.deepEqual(findMoonPhases(segment,left,right),findMoonPhases(engine,left,right));
  const last=jstToUtcMs('2101-01-01','00:00');
  assert.ok(findMoonPhases(engine,last-31*86400000,last).length>=8);
});
