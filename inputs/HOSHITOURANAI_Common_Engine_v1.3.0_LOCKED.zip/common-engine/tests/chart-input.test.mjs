import test from 'node:test';
import assert from 'node:assert/strict';
import {WORLD_CITIES,loadHistoricalTimezones,normalizeChartDate,tripleClockLabel} from '../src/index.mjs';

test('47 Japanese capital presets and unique city IDs',()=>{
  assert.equal(new Set(WORLD_CITIES.map(city=>city.id)).size,57);
  assert.equal(WORLD_CITIES.filter(city=>city.timeZone==='Asia/Tokyo'&&city.id!=='diet').length,47);
  for(const id of ['tokyo','mito','sapporo','naha']) assert.ok(WORLD_CITIES.find(city=>city.id===id));
});

test('Japanese keyboard dates and invalid calendar dates',()=>{
  for(const value of ['2000年12月23日','２０００年１２月２３日','2000/12/23','2000-12-23']){
    assert.equal(normalizeChartDate(value),'2000-12-23');
  }
  assert.throws(()=>normalizeChartDate('2026年2月29日'),RangeError);
});

test('The same target instant uses each chart location’s clock',async()=>{
  const db=await loadHistoricalTimezones();
  const instant=Date.parse('2026-11-20T12:00:00Z');
  assert.equal(tripleClockLabel(db,instant,WORLD_CITIES.find(city=>city.id==='mito')),'2026-11-20 21:00（水戸）');
  assert.equal(tripleClockLabel(db,instant,WORLD_CITIES.find(city=>city.id==='london')),'2026-11-20 12:00（ロンドン）');
});
