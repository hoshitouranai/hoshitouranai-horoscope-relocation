import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import test from 'node:test';
import {
  loadHistoricalTimezones, loadSampledEphemeris, jstToUtcMs, placidusHouses,
  relocationChart, shortestSeparation, vertexAt, vertexPoints, zodiacPosition,
} from '../src/index.mjs';

const ephemeris = await loadSampledEphemeris();
const timezones = await loadHistoricalTimezones();
const references = JSON.parse(await readFile(new URL('./swiss_relocation_reference.json', import.meta.url)));
const origin = { cityId: 'tokyo' };
const request = {
  date: '2027-12-21', time: '09:00', birthLocation: origin, destination: { cityId: 'sydney' },
};

test('relocation keeps a single UTC epoch and set of geocentric bodies', () => {
  const { status, natal, relocated, utcMs } = relocationChart(ephemeris, timezones, request);
  assert.equal(status, 'ok');
  assert.equal(utcMs, Date.parse('2027-12-21T00:00:00Z'));
  assert.equal(natal.clocks.local, '2027-12-21T09:00:00');
  assert.equal(relocated.clocks.local, '2027-12-21T11:00:00');
  assert.equal(natal.utcMs, relocated.utcMs);
  assert.deepEqual(natal.bodies, ephemeris.chart(request.date, request.time).bodies);
  assert.deepEqual(natal.bodies, relocated.bodies);
  assert.notEqual(natal.asc, relocated.asc);
  assert.notEqual(natal.mc, relocated.mc);
  assert.notDeepEqual(natal.cusps, relocated.cusps);
  assert.deepEqual(relocated.vertexAxis, vertexAt(ephemeris, { ...relocated.location, utcMs }));
});

test('relocation to the birth city is identical to the natal chart', () => {
  const { natal, relocated } = relocationChart(ephemeris, timezones, { ...request, destination: origin });
  assert.deepEqual(natal, relocated);
});

test('polar fallback is disclosed and matches Swiss angles and cusps', () => {
  const reference = references.find(row => row.label === 'tromso');
  const { natal, relocated } = relocationChart(ephemeris, timezones, { ...request, destination: reference });
  assert.equal(natal.houseSystem, 'placidus');
  assert.equal(natal.fallbackUsed, false);
  assert.equal(relocated.requestedHouseSystem, 'placidus');
  assert.equal(relocated.houseSystem, 'porphyry');
  assert.equal(relocated.fallbackUsed, true);
  assert.equal(relocated.clocks, null);
  assert.ok(shortestSeparation(relocated.asc, reference.asc) < 0.00001);
  assert.ok(shortestSeparation(relocated.mc, reference.mc) < 0.00001);
  assert.ok(relocated.cusps.every((value, i) => shortestSeparation(value, reference.cusps[i]) < 0.00001));
});

test('birth timezone gaps and folds are preserved and explicit UTC resolves a fold', () => {
  const ny = { ...request, birthLocation: { cityId: 'new-york' }, time: '01:30', date: '2024-11-03' };
  const fold = relocationChart(ephemeris, timezones, ny);
  assert.equal(fold.status, 'ambiguous');
  const choices = fold.candidates.map(({ utcMs }) => utcMs);
  assert.deepEqual(choices, ['05:30', '06:30'].map(time => Date.parse('2024-11-03T' + time + 'Z')));
  for (const birthUtcMs of choices) {
    const result = relocationChart(ephemeris, timezones, { ...ny, birthUtcMs });
    assert.equal(result.relocated.utcMs, birthUtcMs);
  }
  assert.throws(() => relocationChart(ephemeris, timezones, { ...ny, birthUtcMs: 0 }), RangeError);
  const gap = relocationChart(ephemeris, timezones, { ...ny, date: '2024-03-10', time: '02:30' });
  assert.equal(gap.status, 'nonexistent');
});

test('Swiss comparison across all sample segments and latitude regimes', t => {
  const maxima = { vertex: 0, antiVertex: 0, asc: 0, mc: 0, cusps: 0 };
  for (const row of references) {
    const { status, vertex, antiVertex } = vertexAt(ephemeris, row);
    assert.equal(status, 'ok', row.label);
    assert.ok(Math.abs(shortestSeparation(vertex.longitude, antiVertex.longitude) - 180) < 1e-10);
    for (const point of [vertex, antiVertex]) {
      assert.deepEqual(point, { longitude: point.longitude, ...zodiacPosition(point.longitude) });
    }
    const step = (row.utcMs - jstToUtcMs('2000-01-01', '00:00')) / 10800000;
    const { theta, obliquity } = ephemeris.orientation(step);
    const { asc, mc, cusps, house } = placidusHouses(theta, obliquity, row.latitude, row.longitude);
    assert.equal(house === 'ポーフィリー', row.fallbackUsed, row.label);
    const errors = {
      vertex: shortestSeparation(vertex.longitude, row.vertex),
      antiVertex: shortestSeparation(antiVertex.longitude, row.vertex + 180),
      asc: shortestSeparation(asc, row.asc),
      mc: shortestSeparation(mc, row.mc),
      cusps: Math.max(...cusps.map((value, index) => shortestSeparation(value, row.cusps[index]))),
    };
    for (const [key, error] of Object.entries(errors)) {
      assert.ok(error < 0.00001, row.label + ' ' + key + ': ' + error);
      maxima[key] = Math.max(maxima[key], error);
    }
  }
  t.diagnostic('Maximum angular errors in degrees for ' + references.length + ' Swiss cases: ' + JSON.stringify(maxima));
});

test('Vertex reports geometrically undefined axes and rejects invalid coordinates', () => {
  for (const [theta, latitude] of [[90, 23.44], [270, -23.44]]) {
    assert.deepEqual(vertexPoints(theta, 23.44, latitude, 0),
      { status: 'coincident-planes', vertex: null, antiVertex: null });
  }
  assert.deepEqual(vertexPoints(0, 23.44, 0, 0),
    { status: 'no-western-intersection', vertex: null, antiVertex: null });
  for (const latitude of [-90, 90, NaN]) {
    assert.throws(() => vertexPoints(30, 23.44, latitude, 0), RangeError);
  }
  assert.throws(() => vertexAt(ephemeris, { utcMs: NaN, latitude: 0, longitude: 0 }), RangeError);
});
