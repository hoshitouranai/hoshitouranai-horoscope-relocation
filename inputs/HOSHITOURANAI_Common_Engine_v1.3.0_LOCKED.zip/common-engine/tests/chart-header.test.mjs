import test from 'node:test';
import assert from 'node:assert/strict';
import {CHART_HEADER, mountChartHeader} from '../src/chart-header.mjs';

test('Chart selection updates the title, subtitle, and four guide entries', () => {
  const title = {};
  const subtitle = {};
  const details = {open: false};
  const guide = {
    closest: () => details,
    replaceChildren(...entries) { this.entries = entries; },
  };
  const document = {createElement: tag => ({tag})};
  const nodes = {'h1': title, '[data-chart-subtitle]': subtitle, '[data-chart-guide]': guide};
  const select = mountChartHeader({ownerDocument: document, querySelector: selector => nodes[selector]}, 'single');
  select();
  assert.equal(title.textContent, 'シングルチャート作成');
  for (const [kind, content] of Object.entries(CHART_HEADER)) {
    select(kind);
    assert.equal(title.textContent, content.title);
    assert.equal(subtitle.textContent, content.subtitle);
    assert.equal(document.title, content.title + '｜HOSHITOURANAI');
    assert.deepEqual(guide.entries.map(node => node.textContent), content.guide.flat());
    assert.equal(guide.entries.length, 8);
    assert.equal(details.open, false);
    details.open = true;
    select(kind);
    assert.equal(details.open, true);
  }
  select('invalid');
  assert.equal(title.textContent, CHART_HEADER.triple.title);
});
