import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {regiomontanusHouses,regiomontanusHousesFromGreenwich,placidusHouses} from '../src/index.mjs';
const reference=JSON.parse(readFileSync(new URL('./swiss_regiomontanus_reference.json',import.meta.url)));
const angularDiff=(a,b)=>Math.abs((((a-b)+540)%360)-180);
test('Regiomontanus versus independently generated Swiss Ephemeris houses_armc: 300 cases, 12 cusps plus ASC/MC',()=>{
 let max=0;
 for (const [n,c] of reference.cases.entries()){
  const out=regiomontanusHouses(c.armc,c.obliquity,c.latitude);
  for(let i=0;i<12;i++){
   const err=angularDiff(out.cusps[i],c.cusps[i]);
   max=Math.max(max,err);
   assert.ok(err < 1e-8,`case ${n}, cusp ${i+1}: ${err}°`);
  }
  assert.ok(angularDiff(out.asc,c.asc)<1e-8);
  assert.ok(angularDiff(out.mc,c.mc)<1e-8);
  for(let i=0;i<6;i++)assert.ok(angularDiff(out.cusps[i],out.cusps[i+6]+180)<1e-10);
 }
 console.log('Regiomontanus max angular difference versus Swiss: ',max,'degrees');
});
test('Greenwich orientation + east-positive longitude agrees with ARMC input',()=>{
 const a=regiomontanusHousesFromGreenwich(205.295715851,23.43782083,35.676,139.745);
 const b=regiomontanusHouses(345.040715851,23.43782083,35.676);
 for(let i=0;i<12;i++)assert.ok(angularDiff(a.cusps[i],b.cusps[i])<1e-10);
});
test('Placidus remains independent and unchanged, Regiomontanus produces distinct intermediary cusps',()=>{
 const armc=345.040715851,eps=23.43782083,lat=35.676;
 const p=placidusHouses(armc,eps,lat,0);
 const r=regiomontanusHouses(armc,eps,lat);
 assert.ok(angularDiff(p.cusps[0],r.cusps[0])<1e-10);
 assert.ok(angularDiff(p.cusps[9],r.cusps[9])<1e-10);
 assert.ok(angularDiff(p.cusps[10],r.cusps[10])>0.001);
});
test('Inputs are validated; polar region explicitly unsupported',()=>{
 assert.throws(()=>regiomontanusHouses(NaN,23.4,35),RangeError);
 assert.throws(()=>regiomontanusHouses(0,0,35),RangeError);
 assert.throws(()=>regiomontanusHouses(0,23.4,90),RangeError);
 assert.throws(()=>regiomontanusHouses(0,23.4,70),RangeError);
 assert.throws(()=>regiomontanusHousesFromGreenwich(0,23.4,35,190),RangeError);
});
