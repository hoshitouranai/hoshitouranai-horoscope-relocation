# HOSHITOURANAI Common Engine v1.1

Release date: 2026-11-21 JST. The public entry point is `src/index.mjs`.
This archive includes the engine, the 1900–2100 data, the generation
inputs and scripts, and all fixtures required for the standard restore.

The v1.0 LOCKED baseline has archive SHA-256
`aa6e93d658eb574534692c57e5ba2e5c19e433d90f136ea3789cdba022b0484b`.
Its data, generators, and existing calculation tests are unchanged.
The v1.1 checkpoint adds display and analysis APIs. The C5 R2 rendering
rules provide the retrograde convention and badge geometry used by future
triple charts. See [Retrograde display](RETROGRADE-DISPLAY.md).

Run `bash research/restore.sh` using Bash, Node.js 20+, Python 3 and a
C compiler. The standard test rebuilds the outer ephemeris segments
and the extended time-zone table, compares them with the release data,
and checks the 14,941-record moon-phase regression against the v1.0
HTML digest. The 2000–2050 ephemeris segment remains a pinned input.
The regression fixture is independent of the full 1900–2100 date range.

The triple wheel application and device-specific PNG acceptance are
separate application work. The prior v1.0 archive is retained.

The prior GitHub workflow required merging six upload batches before
running verification. This archive keeps the directory tree and the
standard restore inputs together. If GitHub distribution is changed
later, verify its downloaded contents separately. The dedicated source
repository is `hoshitouranai/hoshitouranai-common-engine`.
