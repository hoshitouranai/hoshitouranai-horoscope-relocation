# Chart place labels

Use the context of each chart to label its location field. Import `chartPlaceLabel` from the shared engine and pass the context of the corresponding chart.

| Context | Japanese label |
| --- | --- |
| Birth chart, including both birth inputs for a composite | 出生地 |
| Event chart, including a selected lunation or ingress | 開催地・対象地域 |
| Transit chart | 観測地 |

For the reference-place composite method, use `COMPOSITE_REFERENCE_PLACE_COPY` beside the separate reference city selector. The selected latitude affects ASC and the 12 houses. The composite planetary longitudes and MC are independent of that selection.
