# Common Engine v1.2.0

Approved on 2026-11-22 JST. The editor accepted the integrated review on PC and iPad.
Review application commit: de9ccecb282ebe367187c814e8540977cfcce118.
The engine retains the tested rc.3 source and inputs. The review application uses
.js extensions for its deployed modules and enables chart submission after setup.
Run bash research/restore.sh to reproduce the verification.
