# Hoshitouranai wordmark

Place the existing brand icon immediately to the left of the visible uppercase HOSHITOURANAI wordmark in application headers and branded chart exports. Keep the icon square, vertically centered, and unchanged in color. Preserve the visible chart title as a separate label.

For HTML, reuse the icon and the wordmark stylesheet from `dist/engine/brand`:

```html
<link rel="stylesheet" href="engine/brand/wordmark.css">
<span class="hoshitouranai-wordmark">
  <img src="engine/brand/icon.png" alt="" width="26" height="26">HOSHITOURANAI
</span>
```

The icon is byte-identical to the asset used by the official single-chart renderer and the aspect-diagram renderer.
