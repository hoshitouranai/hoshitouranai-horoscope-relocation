# Chart attribution notice

Show the shared chart attribution notice on the official home page and in every current or future Hoshitouranai app that generates horoscope charts. Place it in a visible usage note near the chart, its export controls, or the page footer. Use the Japanese text provided by `CHART_ATTRIBUTION` for Japanese pages, including the lowercase domain `hoshitouranai.com`. The product wordmark remains uppercase.

The notice describes free use and requests credit in a video description or course material when a generated chart is reused. Link the domain to the official site.
