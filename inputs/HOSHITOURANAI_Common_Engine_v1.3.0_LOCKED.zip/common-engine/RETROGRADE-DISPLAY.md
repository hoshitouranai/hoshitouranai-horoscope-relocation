# Locked retrograde display foundation for the triple chart

The shared API in `source/index.mjs` pins the display contract from
[C5 R2](https://chatgpt.com/library?file_id=libfile_b14546defb588191a00e559037d2b85a&account_id=personal).
C5 R2 archive SHA-256:
`2b165a9d76ad2a5826aa644264a59b613179f452c3bd419ed3a622435720220e`.

For a glyph-only ring, call `retrogradeGlyph(glyph, planet.retrograde)` on
each planet in its own layer. For badges, call
`retrogradeBadgeLayout(half, planet.retrograde, isDial)` and draw the
glyph and optional bold mark at the returned offsets. For a separate
label, use `RETROGRADE_MARK`. The mark must be part of the chart artwork
so it also appears in exported PNGs. Use the retrograde flag from each
layer's calculated planet data. Missing status does not add a mark.

The API freezes the retrograde rule and C5 badge geometry. Triple-wheel
radii, the final glyph-only appearance, and device and PNG acceptance
belong to the triple-chart implementation. The prior v1.1 checkpoint
The triple-chart foundation does not include device-specific acceptance.

Run `bash research/restore.sh` after extraction. The script checks all archived
files, rebuilds the generated data, and runs the
common-engine and retrograde checks.
