# Common Engine 1.2.0-rc.3 checkpoint

Base: Common Engine 1.2.0-rc.2 chart header checkpoint.
Implementation sources: approved Timeline commit 8579c2c and Comparison C5 R13 commit d25fda3.
The city catalog matches both approved application builds. The date entry and triple-chart presentation are available through the engine entry point.
Run `bash research/restore.sh` to verify checksums, rebuild input data, and run the test and regression suites.
Pending: physical browser checks of an app wired to these exports, release approval, and canonical GitHub synchronization.
