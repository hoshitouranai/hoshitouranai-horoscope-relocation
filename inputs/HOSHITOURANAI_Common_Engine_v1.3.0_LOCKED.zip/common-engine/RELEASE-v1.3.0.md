# Common Engine v1.3.0 LOCKED

Approved by the editor on 2026-11-24 JST. This release preserves the calculation
code, data, tests, and restore command from the approved v1.3.0-rc.1 checkpoint.

Approved checkpoint SHA-256:
`4899d7ccd5005c8c051b983f6b5413633c5266d1dc6a6cd06d3a61a86d03f2f8`.

See [Relocation and Vertex API](RELOCATION.md) for usage and integration.
Run `bash research/restore.sh` to reproduce validation. Deployment and app
integration are outside this engine release.
