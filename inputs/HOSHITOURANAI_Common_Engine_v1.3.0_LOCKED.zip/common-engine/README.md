# HOSHITOURANAI Common Engine v1.2.0-rc.2

Shared calculation and rendering library for HOSHITOURANAI applications.
The public entry point is `src/index.mjs`. Use Node.js 20+ or serve the
source and its adjacent data directory together over HTTP(S).

```js
import { loadEphemerisSegment, aspectsAt } from './src/index.mjs';

const engine = await loadEphemerisSegment('1900-01-01');
const chart = engine.chart('1900-01-01', '12:00');
const aspects = aspectsAt(chart.bodies.map(body => body.longitude));
```

Chart input coverage is 1900-01-01 00:00 through 2100-12-31 23:59 JST.
Use `loadSampledEphemeris()` for calculations spanning ephemeris segments,
and `loadHistoricalTimezones()` and `civilTimeToUtc()` for local civil time.
Dates beyond the last observed time-zone transitions use the bundled rules.

## Restore and verify

Run `bash research/restore.sh` from the extracted package. Requirements
are Bash, Node.js 20+, Python 3 and a C compiler. See [the release record](BASELINE-v1.1-LOCKED.md)
for the archived inputs and expected outputs. Swiss Ephemeris and time-zone
notices are in `research/swiss` and `research/tzdata`.

## Shared display rules

- [Retrograde marks and layered charts](RETROGRADE-DISPLAY.md)
- [Place labels](CHART-PLACE-LABELS.md)
- [Brand wordmark](BRAND.md)
- [Attribution notice](CHART-ATTRIBUTION.md)

## Display update candidate 1.2.0-rc.1

The baseline is the v1.1 LOCKED kit. This candidate provides the shared angle label spacing, double-chart house number band, outer glyph layout and leader lines, aspect-frame legend, and retrograde color. Consumers import layout and style exports from `src/chart-display.mjs` and retrograde styles from `src/retrograde-display.mjs`. The compact aspect endpoints retain circle and square frames for the inner and outer charts respectively.

Restore and verify with `bash research/restore.sh`. Physical iPad Safari acceptance is pending.

## Shared chart header and feature guide

`src/chart-header.mjs` and `src/chart-header.css` provide the common header for single, double and triple chart builders. Use a `[data-chart-header]` root with an `h1`, a `[data-chart-subtitle]`, and a `[data-chart-guide]` list inside native `details`. The selected chart kind supplies the title, subtitle, tab title and guide entries. In a builder with a `#chartKind` selector, the module follows the selected kind. The guide starts collapsed and closes when changing chart kind. The builder retains its own chart parameters and results below the header. For a two-mode builder, expose single and double in its selector.

## Chart input and triple presentation (1.2.0)

- Populate city selectors from `WORLD_CITIES`. It includes Japan's 47 prefectural capitals, the National Diet, and the existing overseas locations. Coordinates are representative presets.
- Use `enableKeyboardDateEntry` on date inputs and `normalizeChartDate` before time conversion in keyboard mode. Standard Safari entry points keep native date controls.
- For a triple wheel built with the C5 viewBox, call `styleTripleWheel(svg, footer)` on the existing C5 brand footer, then `appendTripleCornerLabels(svg, middleName, labels)` with `birth`, `progression`, and `target` labels. Use `tripleClockLabel` with the natal city's timezone for the progression target and the selected transit city's timezone for the transit target.
- Apply `TRIPLE_TITLE_STYLE` to the optional on-screen title and `TRIPLE_ANGLE_LABELS` to the triple angle-name and degree baselines. Export the decorated SVG with `makeTriplePng(svg, {title})` for a 1600 × 1600 image.
- Before releasing a derived app, check keyboard dates, Safari's native date control, separate natal and transit timezones, angle legibility, SVG corner placement, and the saved PNG. The calculation and display rules for single and double charts retain their existing contracts.

See [Relocation and Vertex API](RELOCATION.md) for v1.3 extension usage and validation.
