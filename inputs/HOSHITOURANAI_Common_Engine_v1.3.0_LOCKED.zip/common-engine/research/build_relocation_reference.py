"""Generate reference chart angles directly through the bundled Swiss C API."""
import ctypes as c
from datetime import datetime
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
CASES = [
    ("1900-segment", "1910-01-01T00:34:56+00:00", 35.6762, 139.6503),
    ("utc-year-boundary", "1999-12-31T15:00:00+00:00", 51.5074, -0.1278),
    ("new-york", "2024-11-03T05:30:00+00:00", 40.7128, -74.006),
    ("sydney", "2024-11-03T06:30:00+00:00", -33.8688, 151.2093),
    ("singapore", "2027-07-01T12:00:00+00:00", 1.3521, 103.8198),
    ("southern-tropics", "2027-07-01T18:19:00+00:00", -12.0464, -77.0428),
    ("equator", "2027-01-21T02:18:00+00:00", 0, 0),
    ("tromso", "2027-12-21T00:00:00+00:00", 69.6492, 18.9553),
    ("antarctica", "2028-06-20T12:08:00+00:00", -77.8419, 166.6863),
    ("near-north-pole", "2099-09-20T19:10:00+00:00", 89.999, 180),
    ("near-south-pole", "2099-12-21T12:00:00+00:00", -89.999, -180),
]


def generate(library):
    swiss = c.CDLL(str(library))
    doubles = c.POINTER(c.c_double)
    swiss.swe_houses_ex.argtypes = [
        c.c_double, c.c_int, c.c_double, c.c_double, c.c_int, doubles, doubles,
    ]
    for label, timestamp, latitude, longitude in CASES:
        utc = datetime.fromisoformat(timestamp).timestamp()
        cusps = (c.c_double * 13)()
        points = (c.c_double * 10)()
        result = swiss.swe_houses_ex(utc / 86400 + 2440587.5, 0, latitude, longitude,
                                    ord("P"), cusps, points)
        yield dict(label=label, utcMs=int(utc * 1000), latitude=latitude,
                   longitude=longitude, fallbackUsed=result < 0, asc=points[0],
                   mc=points[1], vertex=points[3], cusps=list(cusps)[1:])


if __name__ == "__main__":
    with tempfile.TemporaryDirectory() as tmp:
        library = Path(tmp) / "libswe.so"
        subprocess.run(["cc", "-O2", "-shared", "-fPIC", "-o", str(library),
                        *map(str, sorted((ROOT / "swiss").glob("*.c"))), "-lm"], check=True)
        rows = list(generate(library))
    Path(sys.argv[1]).write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")
