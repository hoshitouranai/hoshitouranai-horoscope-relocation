import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const [source,module,output]=process.argv.slice(2);
const {loadSampledEphemeris,findMoonPhases,jstToUtcMs,utcMsToJst}=await import(pathToFileURL(module));
const html=readFileSync(source,'utf8');
const row=/^const eventData = (.*?);?\r?$/m;
const data=JSON.parse(html.match(row)[1]);
const keys=['new0','phase450','phase900','phase1350','full0','phase2250','phase2700','phase3150'];
const events=findMoonPhases(await loadSampledEphemeris(),jstToUtcMs('1900-01-01','00:00'),jstToUtcMs('2051-01-01','00:00'));
const original=Object.entries(data).filter(([year])=>+year>=1900&&+year<=2050)
 .flatMap(([,year])=>keys.flatMap((key,index)=>year[key].map(item=>({index,item,utc:jstToUtcMs(...item[0].replaceAll('/','-').split(' '))}))))
 .sort((a,b)=>a.utc-b.utc);
assert.equal(events.length,original.length);
for (const [i,event] of events.entries()) {
 const {index,item,utc}=original[i];
 assert.equal(event.index,index);
 assert.ok(Math.abs(event.utcMs-utc)<=30000);
 const rounded=Math.round(event.utcMs/60000)*60000;
 const displayed=event.utcMs-utc===30000 ? utc : rounded;
 const {date,time}=utcMsToJst(displayed);
 item[0]=date.replaceAll('-','/')+' '+time;
}
const result=html.replace(row,()=> 'const eventData = '+JSON.stringify(data)+';');
assert.deepEqual(JSON.parse(result.match(row)[1]),JSON.parse(html.match(row)[1]));
writeFileSync(output,result.replace(/<!doctype html>/i,'$&\n<!-- Moon phase dates generated with Hoshitouranai common engine v0.11. -->'));
console.log('PASS '+events.length+' phase records; all chart records match');
