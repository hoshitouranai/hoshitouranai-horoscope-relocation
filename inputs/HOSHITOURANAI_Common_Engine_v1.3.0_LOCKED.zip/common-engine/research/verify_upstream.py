"""Compare unchanged engine files and extracted aspects with the source ZIPs."""
from hashlib import sha256
import json
from pathlib import Path
import sys
from zipfile import ZipFile

root = Path(__file__).resolve().parent.parent
records = json.loads((root/'research/upstream.json').read_text())
base, aspect = map(Path, sys.argv[1:])
for record, file in zip(records, [base, aspect], strict=True):
    assert sha256(file.read_bytes()).hexdigest() == record['sha256']
    with ZipFile(file) as archive:
        for name, digest in record['members'].items():
            assert sha256(archive.read(name)).hexdigest() == digest

changes = {'README.md', 'SHA256SUMS.txt', 'package.json', 'src/ephemeris.mjs',
           'src/index.mjs', 'src/historical-time.mjs'}
with ZipFile(base) as archive:
    for name in records[0]['members'].keys() - changes:
        assert (root/name).read_bytes() == archive.read(name), name
with ZipFile(aspect) as archive:
    html = archive.read('aspect_extension_WORKING.html').decode()
    start, end = html.index('const MAJOR='), html.index('function getPositions')
    extracted = html[start:end] + '\nexport {detect, pairList, signConcentrationCandidates, overlapCandidates, APPROVAL};\n'
    assert extracted.encode() == archive.read('aspect_patterns.mjs')
    assert (root/'src/aspect_patterns.mjs').read_text() == extracted
print('PASS: upstream archives and untouched engine files; aspect extraction byte-identical')
