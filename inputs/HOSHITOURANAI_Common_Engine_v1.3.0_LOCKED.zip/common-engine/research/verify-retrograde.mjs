import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';

const {RETROGRADE_MARK, retrogradeGlyph, retrogradeBadgeLayout} =
  await import(pathToFileURL(resolve(process.argv[2] ?? 'source', 'index.mjs')));

assert.equal(RETROGRADE_MARK, 'R');
assert.equal(retrogradeGlyph('☿', true), '☿ᴿ');
for (const status of [false, null, undefined]) {
  assert.equal(retrogradeGlyph('☿', status), '☿');
}
for (const [dial, fullSize] of [[false, 14], [false, 16], [true, 10]]) {
  for (const scale of [1, .82, .66, .52, .42]) {
    const half = fullSize * scale;
    assert.deepEqual(retrogradeBadgeLayout(half, true, dial), {
      glyphY: -half * (dial ? .35 : .36),
      glyphSize: half * 1.25,
      mark: {text: 'R', y: half * .55, size: half * (dial ? .75 : .65)},
    });
    assert.deepEqual(retrogradeBadgeLayout(half, false, dial), {
      glyphY: 0, glyphSize: half * (dial ? 1.55 : 1.48), mark: null,
    });
  }
}
console.log('C5 R2 retrograde marker and badge geometry matched at all 15 size combinations.');

const {renderWheelSvg, renderLayeredWheelSvg} = await import(
  pathToFileURL(resolve(process.argv[2] ?? 'src', 'index.mjs')));
const cusps = Array.from({length: 12}, (_, i) => i * 30);
const direct = {cusps, planets: [{name: '水星', longitude: 22, retrograde: false}]};
const retrograde = {cusps, planets: [{name: '水星', longitude: 22, retrograde: true}]};
assert.match(renderWheelSvg(retrograde), /☿<tspan fill="#a6212d"[^>]*>R<\/tspan>/);
for (const charts of [[direct, retrograde], [direct, retrograde, direct]]) {
  const svg = renderLayeredWheelSvg(charts);
  assert.equal([...svg.matchAll(/☿<tspan fill="#a6212d"[^>]*>R<\/tspan>/g)].length, 1);
  assert.match(svg, /<g aria-label="(?:外円|中円)"[^>]*>[^]*?☿<tspan[^>]*>R<\/tspan><\/text><\/g>/);
}
console.log('Verified visible retrograde lettering in single, double and triple-layer SVG output.');
