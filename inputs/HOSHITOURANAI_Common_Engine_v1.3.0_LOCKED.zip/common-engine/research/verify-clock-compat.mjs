Array.prototype.findLast=undefined;
process.argv[2]=new URL('../src/index.mjs',import.meta.url).pathname;
await import('./addons/world-city/verify.mjs');
