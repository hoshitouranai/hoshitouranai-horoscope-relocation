function earthOrientation(step) {
  const index = Math.floor(step), fraction = step-index, offset = index*8;
  const theta = earthSamples.getUint32(offset,true)/1e7;
  const nextTheta = earthSamples.getUint32(offset+8,true)/1e7;
  const eps = earthSamples.getUint32(offset+4,true)/1e7;
  const nextEps = earthSamples.getUint32(offset+12,true)/1e7;
  return [wrap(theta+fraction*wrap(nextTheta-theta)),eps+fraction*(nextEps-eps)];
}
