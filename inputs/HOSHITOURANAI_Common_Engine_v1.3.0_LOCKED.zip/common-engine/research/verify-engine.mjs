import assert from 'node:assert/strict';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const api = await import(pathToFileURL(resolve(process.argv[2], 'index.mjs')));
const chart = {cusps:Array.from({length:12}, (_,i)=>i*30)};
const expected = ['#ff3035','#00c06b','#ffdc53','#f69abe','#ffb23e','#8dc127','#00cbd0','#cb141b','#8647fb','#505050','#33b7f4','#d99be8'];
for (const svg of [api.renderWheelSvg(chart),api.renderLayeredWheelSvg([chart,chart])]) {
  const signs = [...svg.matchAll(/<text x="([^"]+)" y="([^"]+)"[^>]*fill="(#[a-f0-9]+)">([^<]+)<\/text>/g)];
  assert.deepEqual(signs.map(sign=>sign[3]),expected);
  assert.equal(signs.map(sign=>sign[4][0]).join(''),'♈♉♊♋♌♍♎♏♐♑♒♓');
  signs.forEach((sign,i)=>{
    const next=signs[(i+1)%12];
    assert.ok((sign[1]-350)*(next[2]-350)-(sign[2]-350)*(next[1]-350)<0);
  });
}
assert.equal(api.degreeTicks(api.wheelPoint,270).length,360);
assert.deepEqual(api.angleMarkers({asc:15,mc:95},api.wheelPoint,310).map(mark=>mark.longitude),[15,95,195,275]);
console.log('PASS: glyphs, colors, counterclockwise order, ticks, and angle markers');
