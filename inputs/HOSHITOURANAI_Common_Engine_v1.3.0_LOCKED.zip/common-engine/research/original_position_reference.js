function position(index, step) {
  const sample = Math.floor(step), t = step - sample;
  const stride = names.length*8, offset = sample*stride+index*8;
  const p0 = samples.getInt32(offset,true)/scale;
  const v0 = samples.getInt32(offset+4,true)/scale;
  const p1 = samples.getInt32(offset+stride,true)/scale;
  const v1 = samples.getInt32(offset+stride+4,true)/scale;
  const delta = wrap(p1-p0+180)-180;
  const longitude = wrap(p0+delta*t*t*(3-2*t)+t*(1-t)*(v0*(1-t)-v1*t)/8);
  // Station boundaries are calculated at the first JST minute with the new motion.
  const changes = stations[index];
  const minute = Math.round(step*180);
  let lo = 1, hi = changes.length;
  while (lo<hi) {
    const mid = (lo+hi)>>>1;
    if (changes[mid]<=minute) lo=mid+1;
    else hi=mid;
  }
  return {longitude,retrograde:Boolean((changes[0]+lo-1)%2)};
}
