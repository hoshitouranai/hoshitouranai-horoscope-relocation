"""Compare off-grid interpolated positions with direct Swiss calculations."""
import datetime as dt
import json
from pathlib import Path
import subprocess

import swisseph as swe

ROOT = Path(__file__).resolve().parent
swe.set_ephe_path(str(ROOT / 'swiss'))
bodies = [*range(10), swe.TRUE_NODE, swe.CHIRON]
jst = dt.timezone(dt.timedelta(hours=9))
dates = [(f'{y:04}-{m:02}-15', '12:17') for y in range(1900, 2101) for m in range(1, 13)]
dates += [('1900-01-01', '00:00'), ('1904-02-29', '14:05'), ('1999-12-31', '23:59'),
          ('2000-01-01', '00:00'), ('2050-12-31', '23:59'), ('2051-01-01', '00:00'),
          ('2100-12-31', '23:59')]
script = '''
import {readFileSync} from 'node:fs';
import {loadSampledEphemeris} from './src/index.mjs';
const engine = await loadSampledEphemeris();
console.log(JSON.stringify(JSON.parse(readFileSync(0,'utf8')).map(([d,t]) => engine.chart(d,t))));
'''
charts = json.loads(subprocess.check_output(['node', '--input-type=module', '-e', script],
                    cwd=ROOT.parent, input=json.dumps(dates).encode()))
max_longitude = [0.0] * len(bodies)
max_theta = max_obliquity = 0.0

def distance(a, b):
    return abs((a-b+180) % 360 - 180)

for (date, time), chart in zip(dates, charts, strict=True):
    when = dt.datetime.fromisoformat(date+'T'+time).replace(tzinfo=jst)
    jd = 2440587.5 + when.timestamp()/86400
    for i, (body, found) in enumerate(zip(bodies, chart['bodies'], strict=True)):
        flag = swe.FLG_SWIEPH if body == swe.CHIRON else swe.FLG_MOSEPH
        expected, actual_flags = swe.calc_ut(jd, body, flag | swe.FLG_SPEED)
        assert actual_flags & 7 == flag
        error = distance(expected[0], found['longitude'])
        max_longitude[i] = max(max_longitude[i], error)
    theta = distance(chart['orientation']['theta'], swe.sidtime(jd)*15)
    obliquity = abs(chart['orientation']['obliquity'] - swe.calc_ut(jd, swe.ECL_NUT)[0][0])
    max_theta = max(max_theta, theta)
    max_obliquity = max(max_obliquity, obliquity)

print('Swiss version:', swe.version)
print('Dates:', len(dates), 'longitude comparisons:', len(dates)*len(bodies))
print('Maximum longitude error (degrees), BODY_NAMES order:', max_longitude)
print('Maximum theta and obliquity errors (degrees):', max_theta, max_obliquity)
assert max(max_longitude) < 0.0001
assert max(max_theta, max_obliquity) < 0.0001
