#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
sha256sum -c SHA256SUMS.txt
node --test tests/*.test.mjs
restore_dir="$(mktemp -d)"
trap 'rm -rf "$restore_dir"' EXIT
python3 research/build_timezones.py "$restore_dir/timezones_1900_2100.json"
python3 research/build_ephemeris.py "$restore_dir"
for generated in "$restore_dir"/*; do
    cmp "$generated" "data/${generated##*/}"
done
if [ "$#" -eq 2 ]; then
    python3 research/verify_upstream.py "$1" "$2"
fi
echo 'PASS: generated input files byte-identical'
python3 research/build_relocation_reference.py "$restore_dir/swiss_relocation_reference.json"
cmp "$restore_dir/swiss_relocation_reference.json" tests/swiss_relocation_reference.json
echo "PASS: Swiss relocation references byte-identical"
node research/verify-clock-compat.mjs
node research/verify-engine.mjs src
node research/verify-retrograde.mjs src
node research/moon-regression/build.mjs research/moon-regression/input.html "$PWD/src/index.mjs" "$restore_dir/moon-regression.html"
printf '%s  %s\n' '465a3af417540bea0059db9f93ad0765cc81ecc67900c665c96aaf9e1b8375b5' "$restore_dir/moon-regression.html" | sha256sum -c -
