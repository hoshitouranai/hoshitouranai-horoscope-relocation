#!/bin/sh
set -eu
addon=$(dirname "$0")
engine=$1
cp "$addon/aspect-diagram.mjs" "$engine/src/"
export_line="export {renderAspectDiagram} from './aspect-diagram.mjs';"
grep -Fxq "$export_line" "$engine/src/index.mjs" || printf '%s\n' "$export_line" >> "$engine/src/index.mjs"
