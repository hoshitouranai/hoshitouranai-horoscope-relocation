from pathlib import Path
import sys
html=Path(sys.argv[1]).read_text()
i=html.index('  function diagramSvg(')
a=html.index('  const assets =',html.rfind('<script',0,i))
b=html.index('\n  }',i)+4
asset=html.index('globalThis.LockedAspectAssets =')
asset_end=html.index('</script>',asset)
definition=html[asset:asset_end].splitlines()[0]
definition=definition.replace('globalThis.LockedAspectAssets =','const assets =',1)
body=html[a:b].split('\n',1)[1]
Path(sys.argv[2]).write_text(definition+'\n'+body+'\nexport {diagramSvg};\n')
