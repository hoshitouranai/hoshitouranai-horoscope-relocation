# 共通エンジン用 アスペクト模式図

開発用CHECKPOINT。既存のアスペクト拡張版のSVG素材と描画コードを再利用。
ブラウザーで aspect-diagram.mjs の renderAspectDiagram(pattern, positions, utcMs) を呼び出す。
pattern は共通エンジンの detect が返す複合図形、positions は同じ順の黄経、utcMs はUTCミリ秒。
描画にはブラウザーのDOMとCanvasが必要。既存アプリへの接続とSafari画面確認は未実施。

原本は hoshitouranai_aspect_extension_CHECKPOINT_EPHEMERIS_20261113.zip
（libfile_c6788ebcfa0481918eb3ef09b376715b）。展開した aspect_extension_WORKING.html を使う。
復元は python3 extract.py <原本HTML> rebuilt.mjs を実行し、wrapper.txt の前に空行を1行加えて追記し、
aspect-diagram.mjs とバイト比較する。

共通エンジンv0.10の展開コピーに sh install.sh <common-engine> を実行すると公開APIから呼び出せる。
