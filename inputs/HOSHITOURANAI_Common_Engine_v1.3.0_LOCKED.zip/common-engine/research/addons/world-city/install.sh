#!/bin/sh
set -eu
addon=$(dirname "$0")
cp "$addon/world-city.mjs" "$1/src/"
line="export {WORLD_CITIES,searchCities,resolveLocation,clocksAt} from './world-city.mjs';"
grep -Fxq "$line" "$1/src/index.mjs" || printf '%s\n' "$line" >> "$1/src/index.mjs"
