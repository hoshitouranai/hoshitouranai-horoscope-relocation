# 共通エンジン 世界都市・時刻変換 CHECKPOINT

v0.10原本ZIP（libfile_a046cc6a285c819188266bad6c98032a、SHA-256 776757bc15400d4196e2dbfa9bfe0f73186383f0343187d4253aa5f39b54b471）に適用する追加モジュール。
sha256sum -c SHA256SUMS.txt のあと、sh install.sh <展開したcommon-engine> で組み込み、node verify.mjs <common-engine/src/index.mjs> と既存テストを実行する。install.sh はソースのコピーと公開APIの追記を行う。

8タイムゾーンの既存スナップショットを利用。都市は47都道府県庁所在地・国会議事堂・海外9都市の計57地点。座標はプリセットの代表点。既存 civilTimeToUtc で現地時刻をUTCへ変換し、clocksAt でUTCを現地・UTC・JST表示へ変換できる。夏時間の重複・欠落は civilTimeToUtc の状態を使用。手入力の座標だけで観測地点を指定でき、現地時刻の変換には対応タイムゾーンの指定が必要。2051年以降の時差は収録ルールに基づく推計。

次は各アプリの検索欄・東京／国会議事堂ボタンと接続し、同一UTC時刻で観測地点を変える画面回帰を実施。追加都市・タイムゾーン、iPad実機は次工程。
