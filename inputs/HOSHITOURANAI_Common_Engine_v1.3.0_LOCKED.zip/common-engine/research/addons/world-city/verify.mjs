import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const {WORLD_CITIES,loadHistoricalTimezones,civilTimeToUtc,searchCities,resolveLocation,clocksAt}=await import(pathToFileURL(process.argv[2]));
const db=await loadHistoricalTimezones();
for(const c of WORLD_CITIES) assert.deepEqual(resolveLocation(db,{cityId:c.id}),c);
assert.equal(searchCities('New York')[0].id,'new-york');
assert.equal(searchCities('国会')[0].id,'diet');
const utcMs=Date.parse('2026-11-13T20:54:00Z');
for(const [zone,time] of [['Asia/Tokyo','2026-11-14T05:54:00'],['America/New_York','2026-11-13T15:54:00'],['America/Los_Angeles','2026-11-13T12:54:00'],['Europe/London','2026-11-13T20:54:00']]){
 const result=clocksAt(db,utcMs,zone);
 assert.equal(result.local,time);
 assert.equal(result.utc,'2026-11-13T20:54:00');
 assert.equal(result.jst,'2026-11-14T05:54:00');
 assert.equal(civilTimeToUtc(db,{date:time.slice(0,10),time:time.slice(11,16),timeZone:zone}).utcMs,utcMs);
}
assert.equal(clocksAt(db,Date.parse('1949-07-01T03:00Z'),'Asia/Tokyo').offsetSeconds,36000);
assert.equal(civilTimeToUtc(db,{date:'2024-03-10',time:'02:30',timeZone:'America/New_York'}).status,'nonexistent');
assert.equal(civilTimeToUtc(db,{date:'2024-11-03',time:'01:30',timeZone:'America/New_York'}).status,'ambiguous');
assert.equal(resolveLocation(db,{latitude:35,longitude:140}).timeZone,undefined);
console.log('PASS city presets, city search, manual coordinates, four clocks, historical DST and DST gap/fold');
