"""Extend the existing snapshot from bundled TZif data."""
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
from zoneinfo import ZoneInfo

root = Path(__file__).resolve().parent
source = root.parent / 'data/timezones_1900_2050.json'
output = Path(sys.argv[1]) if len(sys.argv) > 1 else source.with_name('timezones_1900_2100.json')
db = json.loads(source.read_text())
start = int(datetime.fromisoformat(db['coverageUtc'][1]).timestamp())
end = int(datetime(2101, 1, 2, tzinfo=timezone.utc).timestamp())
for name, period in db['zones'].items():
    with (root / 'tzdata' / name).open('rb') as file:
        zone = ZoneInfo.from_file(file, name)

    def offset(seconds):
        return int(datetime.fromtimestamp(seconds, zone).utcoffset().total_seconds())

    previous = period[-1][1]
    if offset(start) != previous:
        previous = offset(start)
        period.append([start, previous])
    for low in range(start, end - 1, 3600):
        high = min(low + 3600, end - 1)
        current = offset(high)
        if current == previous:
            continue
        while high - low > 1:
            middle = (low + high) // 2
            if offset(middle) == previous:
                low = middle
            else:
                high = middle
        period.append([high, current])
        previous = current
db['coverageUtc'][1] = '2101-01-02T00:00:00Z'
db['generator'] = 'research/build_timezones.py'
db['source'] = 'v0.7 snapshot through 2050, bundled TZif from 2051'
output.write_text(json.dumps(db, separators=(',', ':')) + '\n')
