# Relocation and Vertex API

Status: v1.3.0 LOCKED. Base: v1.2.0 LOCKED,
SHA-256 `b93ea1684216440197c4c6486954a60f78699e858a234c49814f03ddee24b34c`.

```js
import {
  loadSampledEphemeris, loadHistoricalTimezones, relocationChart, vertexAt,
} from './src/index.mjs';

const [ephemeris, timezones] = await Promise.all([
  loadSampledEphemeris(), loadHistoricalTimezones(),
]);
const result = relocationChart(ephemeris, timezones, {
  date: '2027-12-21', time: '09:00',
  birthLocation: { cityId: 'tokyo' }, destination: { cityId: 'sydney' },
});
if (result.status === 'ok') {
  const { natal, relocated, utcMs } = result;
  // Pass these bodies, cusps and angles into separate chart layers.
  // Read vertexAxis only when a Vertex overlay is enabled.
  const eventAxis = vertexAt(ephemeris, { utcMs, latitude: 35.6762, longitude: 139.6503 });
}
```

The birth clock takes YYYY-MM-DD and HH:mm in the birth location's timezone.
Both locations accept a WORLD_CITIES cityId or coordinates in degrees, east
and north positive. A custom birth location requires a timezone from the
bundled database. A custom destination timezone is optional. With a timezone,
each chart's clocks describe the same instant in local time, UTC and JST.

The historical converter's status is returned for invalid civil instants.
For an ambiguous clock, choose a returned candidate and resubmit its UTC
milliseconds as `birthUtcMs`. The loader's existing 1900–2100 JST ephemeris
coverage and the existing historical timezone coverage apply. Use the combined
loader, whose orientation and position accept steps from 2000-01-01 00:00 JST.

On success, both charts expose `utcMs`, `location`, `orientation`, `clocks`,
`bodies`, `asc`, `mc`, `cusps`, `house`, `requestedHouseSystem`, `houseSystem`,
`fallbackUsed`, and `vertexAxis`. Geocentric tropical positions and retrograde
flags are calculated once and shared as read-only data. Only the location-dependent
coordinates and local clock are recalculated. Placidus is requested for both
charts. The existing engine falls back to Porphyry at absolute latitude
greater than or equal to 90° minus true obliquity, independently at each location.
The application can present the actual house system using `houseSystem`.

## Vertex axis

`vertexAt(ephemeris, { utcMs, latitude, longitude })` works for any chart
instant, including natal and event charts. `vertexPoints(theta, obliquity,
latitude, longitude)` accepts apparent Greenwich sidereal angle and true
obliquity in degrees when the caller already has Earth orientation.

The tropical Vertex is the intersection of the ecliptic and prime vertical
on the western half of the local sky. The calculation projects the local
north vector onto the ecliptic basis, solves the intersection, and uses
the sign of the eastward component to choose the western solution. The
Anti-Vertex is its antipode. An `ok` result exposes `vertex` and `antiVertex`,
each with `longitude` in [0, 360), `signIndex` from 0 (Aries) to 11 (Pisces),
and `degreesInSign` in [0, 30). Near a west/east branch change the longitude
may jump by 180°. No output smoothing is applied. The 1e-12 tolerance on the
unit-vector tests reports coincident planes as `coincident-planes`, and
a north/south-only intersection as `no-western-intersection`. Both fields
are null for these statuses. Geographic poles are outside the coordinate domain,
consistent with the existing house API.

## Reproduction and integration

Run `bash research/restore.sh` with Node.js 20+, Python 3, a C compiler
and GNU coreutils. The command validates the manifest, regenerates the source
data and Swiss fixtures, compares bytes, and runs the old and new tests.
Reference angles come from direct Swiss Ephemeris `swe_houses_ex` calls,
including its Porphyry fallback. The fixture covers all three date segments,
both hemispheres, the equator, polar circles and near-pole sites. The engine's
Earth-orientation inputs originate from sampled Swiss data, while the Vertex
longitude uses the independent geometric calculation above. Precision figures
are maxima over the fixture cases.

For double and triple charts, map natal and relocated data to their own layers.
Display Vx/AVx as optional chart points, and include them in aspects only
when opted in by the application. The release is approved for engine use. Device checks belong to the future application
integration.
