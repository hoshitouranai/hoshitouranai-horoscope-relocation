# Common Engine v1.3.0 Lilith extension

Working extension for HOSHITOURANAI. The base is Common Engine v1.3.0
LOCKED, archive SHA-256
6f1c71c8c8e2a306bd78cbc1e9e916ccfb0cfe53671f9d8e11d862d3d6742556.

The dataset covers JST years 1900 through 2100 inclusive. Each yearly file
contains 15-minute samples of geocentric tropical longitude and the next
January 1 endpoint, allowing interpolation to the final instant of the year.
The library loads the relevant file on demand. Mean is the lunar mean
apogee, and True is the osculating apogee. The generator selects the bundled
Swiss lunar ephemeris and rejects a fallback to another backend.

## Rebuild and verify

Run from the extracted extension directory with Node.js 20+, Python 3,
a Linux C compiler, and a separately extracted v1.3.0 engine. The build
takes a path to that engine, an output directory, and a positive worker
count. The output directory must have room for roughly 57 MB of data.

```sh
python3 build_all.py /path/to/common-engine data 4
sha256sum -c SHA256SUMS
node verify-all.mjs data /path/to/common-engine
```

The builder checks interpolation at three interior times in every interval.
The integration test checks all yearly headers, both ends of all supported
years, all shared boundary samples, out-of-range behavior, and an actual
Tokyo/Sydney relocation. VALIDATION.json records the observed errors.
This extension is a working build. Chart rendering and PC/iPad Safari
device acceptance belong to the application integration.

## Use from a browser

```js
import { createLilithLookup } from './lilith-years.mjs';
import { relocationHouseComparison } from './relocation-house-comparison.mjs';

const lilithAt = createLilithLookup(async year => {
  const response = await fetch(new URL(`./data/lilith-${year}.bin`, import.meta.url));
  if (!response.ok) throw new Error(`Could not load Lilith for ${year}`);
  return response.arrayBuffer();
});

const comparison = relocationResult.status === 'ok'
  ? relocationHouseComparison(relocationResult, await lilithAt(relocationResult.utcMs))
  : relocationResult;
```
