import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createLilithLookup, lilithYearAt } from './lilith-years.mjs';
import { relocationHouseComparison } from './relocation-house-comparison.mjs';

const dataPath = resolve(process.argv[2]);
const engineUrl = pathToFileURL(join(resolve(process.argv[3]), 'src/index.mjs'));
const { loadSampledEphemeris, loadHistoricalTimezones, relocationChart } = await import(engineUrl);
const boundary = year => Date.UTC(year - 1, 11, 31, 15);
const lookup = createLilithLookup(async year =>
  Uint8Array.from(await readFile(join(dataPath, `lilith-${year}.bin`))).buffer);
const max = { mean: { error: 0 }, true: { error: 0 } };
let previousEnd;

for (let year = 1900; year <= 2100; year++) {
  const bin = await readFile(join(dataPath, `lilith-${year}.bin`));
  assert.equal(bin.toString('ascii', 0, 4), 'LIL1');
  assert.equal(bin.readDoubleLE(4), boundary(year));
  assert.equal(bin.readUInt32LE(12), 900_000);
  assert.equal(bin.length, 16 + 8 * (1 + (boundary(year + 1) - boundary(year)) / 900_000));
  if (previousEnd) assert.deepEqual(bin.subarray(16, 24), previousEnd);
  previousEnd = bin.subarray(-8);
  const { maxErrorDegrees } = JSON.parse(await readFile(join(dataPath, `${year}-validation.json`)));
  for (const mode of ['mean', 'true']) {
    const error = maxErrorDegrees[mode];
    assert(Number.isFinite(error) && error >= 0);
    if (error > max[mode].error) max[mode] = { error, year };
  }
  assert.equal(lilithYearAt(boundary(year)), year);
  for (const utc of [boundary(year), boundary(year + 1) - 1]) {
    assert((await lookup(utc)).every(({ longitude }) => longitude >= 0 && longitude < 360));
  }
}
await assert.rejects(lookup(boundary(1900) - 1), RangeError);
await assert.rejects(lookup(boundary(2101)), RangeError);

const [ephemeris, timezones] = await Promise.all([loadSampledEphemeris(), loadHistoricalTimezones()]);
const result = relocationChart(ephemeris, timezones, {
  date: '2027-12-21', time: '09:00',
  birthLocation: { cityId: 'tokyo' }, destination: { cityId: 'sydney' },
});
assert.equal(result.status, 'ok');
const lilith = relocationHouseComparison(result, await lookup(result.utcMs)).shared.slice(-2);
assert.deepEqual(lilith.map(row => [row.natalHouse, row.relocatedHouse]), [[1, 12], [12, 11]]);
assert(lilith.every(row => row.natalLongitude === row.relocatedLongitude));
console.log(JSON.stringify({ years: 201, joinedBoundaries: 200, max, lilith }, null, 2));
