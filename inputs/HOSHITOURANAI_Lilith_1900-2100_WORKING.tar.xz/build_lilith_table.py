"""Build a Lilith table and verify three interior points in every interval.

Arguments: engine directory, UTC start, UTC end, output binary.
Requires Python 3, a C compiler, and the v1.3.0 Swiss source and lunar file.
"""
import ctypes
from datetime import datetime
import json
from pathlib import Path
import subprocess
import sys
import tempfile

engine, start, end, destination, *compiled = sys.argv[1:]
import struct

def utc_seconds(timestamp):
    instant = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
    if instant.tzinfo is None:
        raise ValueError("An explicit UTC offset is required")
    return int(instant.timestamp())

first, last = map(utc_seconds, (start, end))
step = 900
if last <= first or first % step or last % step:
    raise ValueError("Expected increasing times aligned to 15-minute UTC boundaries")
source = Path(engine).resolve() / "research" / "swiss"

with tempfile.TemporaryDirectory() as temp:
    library = Path(temp) / "libswe.so"
    if compiled:
        library = Path(compiled[0]).resolve()
    else:
        subprocess.run(
            ["cc", "-O2", "-fPIC", "-shared", "-o", str(library),
             *map(str, sorted(source.glob("*.c"))), "-lm"],
            check=True,
        )
    swiss = ctypes.CDLL(str(library))
    swiss.swe_set_ephe_path.argtypes = [ctypes.c_char_p]
    swiss.swe_set_ephe_path.restype = None
    swiss.swe_set_ephe_path(str(source).encode())
    swiss.swe_calc_ut.argtypes = [
        ctypes.c_double, ctypes.c_int, ctypes.c_int,
        ctypes.POINTER(ctypes.c_double), ctypes.c_char_p,
    ]
    swiss.swe_calc_ut.restype = ctypes.c_int
    values = (ctypes.c_double * 6)()
    error = ctypes.create_string_buffer(256)
    def longitude(timestamp, body):
        jd = 2440587.5 + timestamp / 86400
        flags = swiss.swe_calc_ut(jd, body, 2 | 256, values, error)
        if flags < 0 or flags & 7 != 2:
            raise RuntimeError(f"{timestamp}, {body}: {error.value.decode()}")
        return values[0]

    with Path(destination).open("wb") as out:
        out.write(struct.pack("<4sdI", b"LIL1", first * 1000, step * 1000))
        max_diff = [0.0, 0.0]
        previous = None
        for timestamp in range(first, last + 1, step):
            row = [round(longitude(timestamp, body) * 1e7) % 3600000000 for body in (12, 13)]
            out.write(struct.pack("<II", *row))
            if previous is not None:
                for i, body in enumerate((12, 13)):
                    a, b = previous[i] / 1e7, row[i] / 1e7
                    for fraction in (0.25, 0.5, 0.75):
                        interpolated = a + ((b - a + 180) % 360 - 180) * fraction
                        actual = longitude(timestamp - step + step * fraction, body)
                        difference = abs((interpolated - actual + 180) % 360 - 180)
                        max_diff[i] = max(max_diff[i], difference)
            previous = row
    print(json.dumps({"start": start, "end": end, "maxErrorDegrees": dict(zip(("mean", "true"), max_diff))}))
