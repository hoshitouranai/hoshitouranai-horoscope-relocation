"""Build one JST year of asteroid samples, including the next year's boundary."""
from datetime import datetime, timedelta, timezone
from pathlib import Path
import subprocess
import sys

engine, year_arg, directory, *compiled = sys.argv[1:]
year = int(year_arg)
if not 1900 <= year <= 2100:
    raise ValueError("Expected a JST year between 1900 and 2100")

jst = timezone(timedelta(hours=9))
start, end = (datetime(y, 1, 1, tzinfo=jst).isoformat() for y in (year, year + 1))
output = Path(directory)
output.mkdir(parents=True, exist_ok=True)
target = output / f"asteroids-{year}.bin"
temporary = target.with_suffix(".tmp")
try:
    subprocess.run(
        [sys.executable, str(Path(__file__).with_name("build_asteroid_table.py")),
         engine, start, end, str(temporary), *compiled],
        check=True,
    )
    temporary.replace(target)
finally:
    temporary.unlink(missing_ok=True)
