import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createAsteroidLookup, fortuneLongitude, wheelLayer } from './extra-chart-points.mjs';
import { createLilithLookup } from './lilith-years.mjs';

const [engine, lilithData] = process.argv.slice(2).map(path => resolve(path));
const load = async path => Uint8Array.from(await readFile(path)).buffer;
const asteroidAt = createAsteroidLookup(year => load(new URL(`./data/asteroids-${year}.bin`, import.meta.url)));
const lilithAt = createLilithLookup(year => load(join(lilithData, `lilith-${year}.bin`)));
const {
  loadSampledEphemeris, loadHistoricalTimezones, relocationChart, renderWheelSvg,
  renderLayeredWheelSvg, wheelPoint,
} = await import(pathToFileURL(join(engine, 'src/index.mjs')));

let previous;
let maxError = 0;
for (let year = 1900; year <= 2100; year++) {
  const data = await readFile(new URL(`./data/asteroids-${year}.bin`, import.meta.url));
  if (previous) assert.deepEqual(data.subarray(16, 32), previous);
  previous = data.subarray(-16);
  const report = JSON.parse(await readFile(new URL(`./data/${year}-validation.json`, import.meta.url)));
  maxError = Math.max(maxError, ...Object.values(report.maxErrorDegrees));
  for (const utc of [Date.UTC(year - 1, 11, 31, 15), Date.UTC(year, 11, 31, 15) - 1]) {
    assert((await asteroidAt(utc)).every(p => p.longitude >= 0 && p.longitude < 360));
  }
}
const [e, t] = await Promise.all([loadSampledEphemeris(), loadHistoricalTimezones()]);
const date = '2027-12-21';
const input = {date, time: '09:00', birthLocation: {cityId: 'tokyo'}, destination: {cityId: 'sydney'}};
const {natal, relocated} = relocationChart(e, t, input);
const another = relocationChart(e, t, {...input, date: '2027-12-22'}).natal;
const deps = {asteroidAt, lilithAt, fortune: {mode: 'sect', sect: 'day'}};
const inner = await wheelLayer(natal, ['ceres','pallas','juno','vesta','meanLilith','trueLilith','vertex','antiVertex','fortune'], deps);
const middle = await wheelLayer(relocated, ['juno','fortune'], deps);
const outer = await wheelLayer(another, ['vesta'], deps);
const expected = [212.91149796377198, 179.35683948101, 122.11037085189012, 138.46556957695194];
assert(inner.planets.slice(12,16).every((p,i) => Math.abs(p.longitude-expected[i]) < 1e-7));
assert.equal(inner.planets.find(p=>p.id==='juno').longitude,middle.planets.find(p=>p.id==='juno').longitude);
assert.notEqual(inner.planets.find(p=>p.id==='fortune').longitude,middle.planets.find(p=>p.id==='fortune').longitude);
assert.notEqual(inner.planets.find(p=>p.id==='vesta').longitude,outer.planets.find(p=>p.id==='vesta').longitude);
assert.equal(fortuneLongitude({ascendant:10,sun:30,moon:50,mode:'sect',sect:'night'}),350);
assert.equal(fortuneLongitude({ascendant:10,sun:30,moon:50,mode:'sect',sect:null}),null);
const [a,b] = [wheelPoint(0,100),wheelPoint(30,100)];
assert(a[0]*b[1]-a[1]*b[0]<0);
for (const [svg, counts] of [
  [renderWheelSvg(inner), [1,1,1,1]],
  [renderLayeredWheelSvg([inner,middle]), [1,1,2,1]],
  [renderLayeredWheelSvg([inner,middle,outer]), [1,1,2,2]],
]) {
  for (const [i,glyph] of ['⚳','⚴','⚵','⚶'].entries()) {
    assert.equal((svg.match(new RegExp('>'+glyph+'<','gu'))??[]).length,counts[i]);
  }
  for (const glyph of ['⚸M','⚸T','Vx','AVx','⊗']) assert(svg.includes(glyph));
}
console.log(JSON.stringify({years:201, boundaries:200, maxErrorDegrees:maxError, wheelLayers:[1,2,3]},null,2));
