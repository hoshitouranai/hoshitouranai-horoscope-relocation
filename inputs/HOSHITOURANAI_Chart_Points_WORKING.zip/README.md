# Additional points for Common Engine v1.3.0

Working extension for the single, layered and relocation wheels. Requires
the extracted v1.3.0 LOCKED engine and the Lilith 1900–2100 working kit.
The base archive SHA-256 is
6f1c71c8c8e2a306bd78cbc1e9e916ccfb0cfe53671f9d8e11d862d3d6742556.

The four asteroid tables use geocentric tropical longitudes, sampled every
three hours from the bundled Swiss Ephemeris. Coverage is 1900–2100 JST.
The builder checks three internal times in each interval against direct
Swiss calculations and rejects ephemeris fallback.

## API

- `createAsteroidLookup(loadTable)` takes an async year-to-ArrayBuffer loader
  and returns an async UTC-millisecond lookup.
- `wheelLayer(chart, selection, dependencies, label)` returns one layer for
  the existing wheel renderers. Pass each ring's own chart and selection.
  Charts provide utcMs, asc, cusps, bodies and optional vertexAxis. For
  charts without vertexAxis, compute it with the base engine's vertexAt
  when the UTC and actual location are available.
- Selection IDs are ceres, pallas, juno, vesta, meanLilith, trueLilith,
  vertex, antiVertex, fortune. Dependencies are asteroidAt, lilithAt and
  fortune. The caller explicitly selects Fortune's mode: day-formula
  always uses ASC + Moon − Sun; sect uses that formula by day and
  ASC + Sun − Moon by night. In sect mode, the caller supplies day or
  night for this chart. An unresolved sect leaves Fortune absent.
- For relocation, pass each of the two charts from the same result.
  Geocentric points share the UTC; Fortune uses the ASC of its own chart.

This work verifies placement and rendering in generated SVG. App controls,
glyph collision layout, asteroid retrograde flags and Safari device
acceptance are pending. Synthetic chart layers need explicit point policies
before enabling site-dependent points.

## Regenerate and check

Run with Linux, Python 3, a C compiler and Node.js 20+.

```sh
python3 build_all_asteroids.py /path/to/common-engine data 4
node verify.mjs /path/to/common-engine /path/to/lilith-kit/data
sha256sum -c SHA256SUMS
```
