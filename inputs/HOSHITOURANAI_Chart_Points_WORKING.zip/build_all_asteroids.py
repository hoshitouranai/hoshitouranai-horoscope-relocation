"""Build every JST year and retain one validation record per year."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys
import tempfile

engine, target, worker_count = sys.argv[1:]
source = Path(engine).resolve() / 'research' / 'swiss'
output = Path(target)
output.mkdir(parents=True, exist_ok=True)
builder = Path(__file__).with_name('build_asteroid_year.py')

with tempfile.TemporaryDirectory() as temp:
    library = Path(temp) / 'libswe.so'
    subprocess.run(
        ['cc', '-O2', '-fPIC', '-shared', '-o', str(library),
         *map(str, sorted(source.glob('*.c'))), '-lm'],
        check=True,
    )

    def build(year):
        result = subprocess.run(
            [sys.executable, str(builder), engine, str(year), target, str(library)],
            check=True, capture_output=True, text=True,
        )
        (output / f'{year}-validation.json').write_text(result.stdout, encoding='utf-8')

    with ThreadPoolExecutor(max_workers=int(worker_count)) as pool:
        for year, _ in zip(range(1900, 2101), pool.map(build, range(1900, 2101))):
            if year % 20 == 0:
                print(f'Validated through {year}', flush=True)
